package dataTransferObjects;

/**
 * Sends information to the graphical interface. Currently not implemented.
 */

public class DisplayDTO {

    private int productCost;
    private int vatRate;
    private int productDescription;
    public void sendToDisplay(){
   } 
}